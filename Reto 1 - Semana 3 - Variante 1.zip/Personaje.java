public class Personaje{
    //Inserte acá los atributos
    
    
    
    //Inserte acá el método constructor
    
    
    
    //Inserte acá los métodos (NO LOS GETTER Y SETTERS)
    
    
    
    //Inserte acá los SETTERS Y GETTERS
    
    
    
}